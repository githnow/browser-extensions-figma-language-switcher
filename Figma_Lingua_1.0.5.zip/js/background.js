chrome.runtime.onInstalled.addListener(function () {
  chrome.tabs.create({
    url: 'https://bot-idea.ru/lingua'
  });
})
